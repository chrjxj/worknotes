To install, copy paste the folders in ~/.atom/packages
