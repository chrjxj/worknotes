# Jetbrains - Tomorrow Themes #

Color schemes for the IntelliJ, PyCharm, PhpStorm, WebStorm and RubyMine IDEs. Has color scheme support for the following languages: C/C++, Java, PHP, Ruby, Python, Scala, Javascript, Coffeescript, Freemarker, Velocity, Smarty, Twig, HAML, YAML, CSS, LESS, SASS, XML, HTML, Apache, XPath, Django, Regex, SQL, GQL and many more.

To install the theme, import the settings.jar within IntelliJ, or PHPStorm, etc.

* Author: Miles Johnson
* Master: https://github.com/ChrisKempson/Tomorrow-Theme
* Fork: https://github.com/milesj/Tomorrow-Theme

Please report any issues or suggestions to the fork listed above. Thanks!